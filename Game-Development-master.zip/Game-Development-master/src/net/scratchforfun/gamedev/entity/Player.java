package net.scratchforfun.gamedev.entity;

import net.scratchforfun.gamedev.util.TextureManager;

import java.awt.*;

/**
 * Created by Magnus on 05/10/2014.
 */
public class Player extends Entity {

    public Player() {
        super("player");
    }
}
