package net.scratchforfun.gamedev.reference;

import javax.swing.*;
import java.awt.*;

/**
 * Created by Scratch on 9/24/2014.
 */
public class ReferencesImage {

    // TODO: Create spritesheet
    public static final Image GRASS = new ImageIcon("res/grass.png").getImage();

}
